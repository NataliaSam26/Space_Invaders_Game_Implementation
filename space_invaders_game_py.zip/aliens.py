from turtle import Turtle

class Alien(Turtle):
    def __init__(self):
        super().__init__()
        self.shape('images/alien.gif')
        self.penup()
        self.up()
        self.speed(0)
        self.setposition(-220, 220)