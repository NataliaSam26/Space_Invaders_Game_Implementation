from turtle import Turtle

class Bullet(Turtle):
    def __init__(self):
        super().__init__()
        self.color('red')
        self.shape('triangle')
        self.penup()
        self.speed(0)
        self.setheading(90)
        self.shapesize(.5, .5)
        self.hideturtle()

    def fire_bullet(self, player):
        x = player.xcor()
        y = player.ycor()
        self.setposition(x, y+50)
        self.showturtle()