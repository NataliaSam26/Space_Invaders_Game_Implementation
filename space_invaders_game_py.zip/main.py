#### GOAL ####
# Using Python Turtle, build the classic shoot 'em up game - space invaders game.

import turtle
from turtle import Turtle, Screen
from aliens import Alien
from bullet import Bullet
from player import Player
from scoreboard import Scoreboard
import time
import random

screen = Screen()
screen.setup(width=700, height=600)
screen.bgcolor('#90ee90')
screen.title('Space Invaders')


# Register shape
turtle.register_shape('images/rocket.gif')
turtle.register_shape('images/alien.gif')

# Create the necessary objects
player = Player()
bullet = Bullet()
alien = Alien()
score = Scoreboard()

# Create keyboard binding
screen.listen()
screen.onkey(player.go_left, 'Left')
screen.onkey(player.go_right, 'Right')
screen.onkey(lambda: bullet.fire_bullet(player), 'space')

alien_speed = 2
bullet_speed = 10

while True:
    alien.forward(alien_speed)
    if alien.xcor() > 220 or alien.xcor() < -220:
        alien.right(180)
        alien.forward(alien_speed)
    bullet.forward(bullet_speed)

    # Detect collision
    if bullet.distance(alien) < 20: # Euclidean Distance

        bullet.hideturtle()
        alien.hideturtle()
        time.sleep(2)

        x = random.randint(-220, 220)
        alien.setposition(x, 220)
        alien.showturtle()

        player.setposition(0, -190)
        score.point()

screen.exitonclick()
