from turtle import Turtle

class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.shape('images/rocket.gif')
        self.penup()
        self.goto(0, -190)

    def go_left(self):
        new_x = self.xcor() - 10
        if new_x < -270:
            new_x = -270
        self.goto(new_x, self.ycor())



    def go_right(self):
        new_x = self.xcor() + 10
        if new_x > 270:
            new_x = 270
        self.goto(new_x, self.ycor())
